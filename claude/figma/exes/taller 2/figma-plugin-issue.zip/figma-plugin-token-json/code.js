const KEY_PREFIX_COLLECTION = `@`;
const NAMESPACE = "org.sds";

exportToJSON();

async function exportToJSON() {
  const collections = figma.variables.getLocalVariableCollections();
  const object = {};
  const { idToKey } = uniqueKeyIdMaps(collections, "id", KEY_PREFIX_COLLECTION);

  collections.forEach(
    (collection) =>
      (object[idToKey[collection.id]] = collectionAsJSON(idToKey, collection)),
  );

  figma.showUI(
    [
      "<style>body { margin: 0 } textarea { width: 100%; height: 100vh; overflow-y: auto; }</style>",
      `<textarea>${JSON.stringify(object, null, 2)}</textarea>`,
    ].join("\n"),
    { width: 700, height: 700 },
  );
}

function collectionAsJSON(
  collectionIdToKeyMap,
  { name, modes, variableIds, id: figmaId },
) {
  const collection = {};
  const { idToKey, keyToId } = uniqueKeyIdMaps(modes, "modeId");
  const modeKeys = Object.values(idToKey);
  collection.$extensions = {
    [NAMESPACE]: { figmaId, modes: modeKeys },
  };
  variableIds.forEach((variableId) => {
    const { name, resolvedType, valuesByMode, description } =
      figma.variables.getVariableById(variableId);
    const value = valuesByMode[keyToId[modeKeys[0]]];
    const fontWeight =
      resolvedType === "FLOAT" &&
      Boolean(name.match(/\/?weight/i)) &&
      "fontWeight";
    const fontFamily =
      resolvedType === "STRING" &&
      Boolean(name.match(/\/?family/i)) &&
      "fontFamily";
    if (
      (value !== undefined &&
        ["COLOR", "FLOAT", "STRING"].includes(resolvedType)) ||
      fontFamily
    ) {
      let obj = collection;
      name.split("/").forEach((groupName) => {
        const safeName = groupName
          .split(/[^\da-zA-Z]+/)
          .join("-")
          .toLowerCase();
        obj[safeName] = obj[safeName] || {};
        obj = obj[safeName];
      });
      obj.$type =
        resolvedType === "COLOR"
          ? "color"
          : resolvedType === "FLOAT"
            ? fontWeight || "number"
            : fontFamily || "unknown";
      obj.$value = valueToJSON(value, resolvedType, collectionIdToKeyMap);
      obj.$description = description || "";
      obj.$extensions = {
        [NAMESPACE]: {
          figmaId: variableId,
          modes: modeKeys.reduce((into, modeKey) => {
            into[modeKey] = valueToJSON(
              valuesByMode[keyToId[modeKey]],
              resolvedType,
              collectionIdToKeyMap,
            );
            return into;
          }, {}),
        },
      };
    }
  });
  return collection;
}

function valueToJSON(value, resolvedType, collectionIdToKeyMap) {
  if (value && value.type === "VARIABLE_ALIAS") {
    const variable = figma.variables.getVariableById(value.id);
    if (!variable) return "UNKNOWN";
    const prefix = collectionIdToKeyMap[variable.variableCollectionId];
    return "{" + prefix + "." + variable.name.replace(/\//g, ".") + "}";
  }
  return resolvedType === "COLOR" ? rgbToHex(value) : value;
}

function uniqueKeyIdMaps(nodesWithNames, idKey, prefix) {
  if (prefix === undefined) prefix = "";
  const idToKey = {};
  const keyToId = {};
  nodesWithNames.forEach(function(node) {
    const key = sanitizeName(node.name);
    let int = 2;
    let uniqueKey = prefix + key;
    while (keyToId[uniqueKey]) {
      uniqueKey = prefix + key + "_" + int;
      int++;
    }
    keyToId[uniqueKey] = node[idKey];
    idToKey[node[idKey]] = uniqueKey;
  });
  return { idToKey: idToKey, keyToId: keyToId };
}

function sanitizeName(name) {
  return name
    .replace(/[^a-zA-Z0-9 ]/g, "")
    .replace(/^ +/, "")
    .replace(/ +$/, "")
    .replace(/ +/g, "_")
    .toLowerCase();
}

function rgbToHex(value) {
  var r = value.r, g = value.g, b = value.b, a = value.a;
  const toHex = function(v) {
    const hex = Math.round(v * 255).toString(16);
    return hex.length === 1 ? "0" + hex : hex;
  };
  const hex = [toHex(r), toHex(g), toHex(b)];
  if (a !== 1) hex.push(toHex(a));
  return "#" + hex.join("");
}
