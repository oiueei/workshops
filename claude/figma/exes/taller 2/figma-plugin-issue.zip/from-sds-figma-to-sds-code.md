# De Figma a Código: Cómo sincronizar tokens del Design System

Guía completa para Claude (y humanos) sobre cómo exportar variables de Figma y aplicarlas al repo `sds-to-sb`. Incluye todos los problemas reales encontrados y sus soluciones.

---

## Arquitectura del sistema de tokens

```
Figma Variables
     │
     ▼ (exportar con plugin)
scripts/tokens/tokens.json       ← fuente de verdad (W3C Token Format)
     │
     ▼ (npm run script:tokens)
scripts/tokens/app.mjs           ← script de transformación
     │
     ▼
src/theme.css                    ← CSS custom properties generado
     │
     ▼
Componentes (button.css, etc.)   ← consumen las variables, NO se tocan
```

**Regla de oro:** solo se modifican `tokens.json` y se regenera `theme.css`. Los componentes nunca se tocan para un cambio de tokens.

---

## Colecciones de tokens en Figma

El archivo Figma tiene estas colecciones (en orden de dependencia):

| Colección Figma | Clave en tokens.json | Prefijo CSS |
|---|---|---|
| Color Primitives | `@color_primitives` | `--sds-color-` |
| Color | `@color` | `--sds-color-` |
| Typography Primitives | `@typography_primitives` | `--sds-typography-` |
| Typography | `@typography` | `--sds-font-` |
| Size | `@size` | `--sds-size-` |
| Responsive | `@responsive` | `--sds-responsive-` |

Los tokens semánticos (`@color`) referencian los primitivos (`@color_primitives`). Ejemplo:
```
--sds-color-background-brand-default: var(--sds-color-hds-bus)
--sds-color-hds-bus: #0000bf
```

---

## Cómo exportar variables de Figma: el Plugin

### Por qué NO funciona la REST API

La Figma REST API (`GET /v1/files/:fileKey/variables/local`) requiere el scope `file_variables:read`. Este scope **solo está disponible en planes Organization o Enterprise**. Con plan Professional o inferior, el scope no aparece en la UI de tokens de Figma aunque el token sea válido.

### La solución: Plugin local en el repo

El repo incluye un plugin de Figma en `scripts/tokens/figma-plugin-token-json/`. Este plugin corre **dentro del editor de Figma** y accede a las variables por la API interna, sin restricciones de plan.

### Pasos para ejecutar el plugin

1. Abrir el archivo Figma
2. **Plugins → Development → Import from manifest…**
3. Seleccionar `scripts/tokens/figma-plugin-token-json/manifest.json`
4. Ejecutar el plugin desde el panel de Plugins
5. Aparece una ventana con el JSON — **Cmd+A → Cmd+C** para copiar todo
6. En el terminal del proyecto:
   ```bash
   ! pbpaste > scripts/tokens/tokens_figma.json
   ```

### Problemas conocidos del plugin y sus soluciones

#### Error 1: "Syntax error on line 233: Unexpected token ..."
El motor JavaScript embebido en Figma no soporta spread operator (`...`). El código original usaba:
```js
return { ...effect, hex, variables };
return { ...paint, variables };
```
**Solución:** reemplazar con `Object.assign()`:
```js
return Object.assign({}, effect, { hex: hex, variables: variables });
return Object.assign({}, paint, { variables: variables });
```
El archivo corregido ya está en el repo. **No revertir este cambio.**

#### Error 2: Plugin tarda más de 5 minutos sin responder
El plugin original llamaba tres APIs async pesadas al mismo tiempo:
- `figma.getLocalEffectStylesAsync()`
- `figma.getLocalPaintStylesAsync()`
- `figma.getLocalTextStylesAsync()`

En archivos grandes estas llamadas son demasiado lentas. **Solución:** el `code.js` actual (versión ligera) solo lee variables con `figma.variables.getLocalVariableCollections()` — síncrono y rápido.

Si en el futuro necesitas también los estilos (efectos, tipografía, pintura), usa `scripts/tokens/figma-plugin-styles-json/` por separado.

---

## Cómo comparar Figma vs Repo

Una vez tienes `tokens_figma.json` exportado, ejecuta este script para ver todas las diferencias:

```bash
node -e "
const fs = require('fs');
const figma = JSON.parse(fs.readFileSync('scripts/tokens/tokens_figma.json'));
const repo = JSON.parse(fs.readFileSync('scripts/tokens/tokens.json'));

const diffs = [];
function compareObjects(figmaObj, repoObj, path) {
  if (typeof figmaObj !== 'object' || figmaObj === null) return;
  for (const key of Object.keys(figmaObj)) {
    if (key === '\$extensions' || key === '\$description') continue;
    const fullPath = path ? path + '.' + key : key;
    if (key === '\$value') {
      const fVal = String(figmaObj[key]);
      const rVal = repoObj ? String(repoObj[key]) : 'MISSING';
      if (fVal !== rVal) diffs.push({ path, figma: fVal, repo: rVal });
    } else if (typeof figmaObj[key] === 'object') {
      compareObjects(figmaObj[key], repoObj ? repoObj[key] : null, fullPath);
    }
  }
}
compareObjects(figma, repo, '');
console.log('Total diferencias:', diffs.length);
diffs.forEach(d => console.log(d.path, '\n  FIGMA:', d.figma, '\n  REPO:', d.repo, '\n'));
"
```

---

## Cómo aplicar los cambios al repo

### Paso 1: Mergear tokens nuevos a tokens.json

```bash
node -e "
const fs = require('fs');
const figma = JSON.parse(fs.readFileSync('scripts/tokens/tokens_figma.json'));
const repo = JSON.parse(fs.readFileSync('scripts/tokens/tokens.json'));

// Añadir nuevas paletas primitivas de Figma
// Ejemplo: repo['@color_primitives']['blue'] = figma['@color_primitives']['blue'];
// Ejemplo: repo['@color_primitives']['hds'] = figma['@color_primitives']['hds'];

// Actualizar referencias semánticas
// Ejemplo: repo['@color']['background']['brand']['default']['\$value'] = '{@color_primitives.HDS.bus}';

fs.writeFileSync('scripts/tokens/tokens.json', JSON.stringify(repo, null, 2));
console.log('tokens.json actualizado');
"
```

### ⚠️ Paso crítico: corregir el namespace

El plugin exporta tokens con namespace `org.sds`. El script `app.mjs` espera `com.figma.sds`. Si los tokens nuevos no tienen el namespace correcto, se generan bajo una **clase CSS** (`.sds-theme-color_primitives-default`) en lugar de `:root`, y las variables NO están disponibles globalmente.

**Síntoma:** los tokens existen en el CSS pero los componentes los ven como `undefined` → colores transparentes.

**Solución: siempre ejecutar este fix después de mergear primitivos nuevos:**

```bash
node -e "
const fs = require('fs');
const repo = JSON.parse(fs.readFileSync('scripts/tokens/tokens.json'));

function fixNamespace(palette) {
  for (const key of Object.keys(palette)) {
    if (key.startsWith('\$')) continue;
    const token = palette[key];
    if (token['\$value'] !== undefined) {
      const orgSds = token['\$extensions'] && token['\$extensions']['org.sds'];
      if (orgSds && !token['\$extensions']['com.figma.sds']) {
        token['\$extensions']['com.figma.sds'] = {
          figmaId: orgSds.figmaId || 'UNDEFINED',
          modes: { value: token['\$value'] }
        };
      }
    } else {
      fixNamespace(token);
    }
  }
}

// Aplicar a cada paleta nueva que venga del plugin
fixNamespace(repo['@color_primitives']['blue']);
fixNamespace(repo['@color_primitives']['hds']);
// Añadir más paletas aquí si hay otras nuevas

fs.writeFileSync('scripts/tokens/tokens.json', JSON.stringify(repo, null, 2));
console.log('Namespace corregido');
"
```

### Paso 2: Regenerar theme.css

```bash
npm run script:tokens
```

Esto lee `tokens.json` y `styles.json` y sobreescribe `src/theme.css`. Necesita un `.env` con:
```
FIGMA_FILE_KEY=IZ39nzqm9fI4HlDSuOjEwk
```

### Paso 3: Verificar

```bash
grep "hds-bus\|background-brand-default" src/theme.css
```

Debe mostrar los tokens bajo `:root`, NO bajo ninguna clase CSS.

### Paso 4: Comprobar en Storybook

```bash
npm run storybook
```

Abre `http://localhost:6006` y busca el componente **Button → primary**. Debe verse con el color de brand actualizado.

---

## Modos de color (light/dark)

`app.mjs` procesa estos modos del archivo Figma:

| Variable en app.mjs | Modo Figma | Output CSS |
|---|---|---|
| `colorSchemes: ["sds_light"]` | SDS Light | `:root { ... }` |
| `colorSchemesDark: ["sds_dark"]` | SDS Dark | `@media (prefers-color-scheme: dark) { :root { ... } }` |
| `brand_b_light` | Brand B Light | ❌ No procesado aún |

Si en el futuro hay que activar `brand_b_light`, añadir `"brand_b_light"` al array `colorSchemes` en `app.mjs` y definir el selector CSS correspondiente.

---

## Cambios del rebranding HDS (Mayo 2026)

Estos son los 29 tokens que cambiaron al pasar a los colores de Helsinki Design System:

### Nuevos primitivos añadidos (18 tokens)

**Paleta `blue`** (10 pasos, 100-1000):
`#f1f6fd` → `#e1ebfa` → `#c0d4f5` → `#9ebef1` → `#3f81ea` → `#3271d7` → `#2a61ba` → `#224a8a` → `#183057` → `#15253f`

**Paleta `hds`** (8 colores):
| Nombre | Valor |
|---|---|
| `hds-bus` | `#0000bf` (azul principal) |
| `hds-bus-dark` | `#00005e` |
| `hds-metro` | `#fd4f00` |
| `hds-cooper` | `#00d7a7` |
| `hds-suomenlinna` | `#f5a3c7` |
| `hds-suomenlinna-light` | `#fff0f7` |
| `hds-summer` | `#ffc61e` |
| `hds-gold` | `#c2a251` |

### Tokens semánticos actualizados (11 tokens)

| Token CSS | Antes | Después |
|---|---|---|
| `--sds-color-background-brand-default` | `brand-800` (#2c2c2c) | `hds-bus` (#0000bf) |
| `--sds-color-background-brand-hover` | `brand-900` | `hds-bus-dark` |
| `--sds-color-background-brand-secondary` | `brand-200` | `hds-metro` |
| `--sds-color-background-brand-tertiary` | `brand-100` | `hds-cooper` |
| `--sds-color-background-default-default` | `white-1000` (#ffffff) | `hds-suomenlinna-light` (#fff0f7) |
| `--sds-color-background-disabled-default` | `brand-300` | `gray-300` |
| `--sds-color-text-disabled-default` | `brand-400` | `gray-400` |
| `--sds-color-text-disabled-on-disabled` | `brand-400` | `gray-400` |
| `--sds-color-border-disabled-default` | `brand-400` | `gray-400` |
| `--sds-color-icon-disabled-default` | `brand-400` | `gray-400` |
| `--sds-color-icon-disabled-on-disabled` | `brand-400` | `gray-400` |

---

## Archivos relevantes

| Archivo | Propósito |
|---|---|
| `scripts/tokens/tokens.json` | Fuente de verdad de todos los tokens (W3C format) |
| `scripts/tokens/tokens_figma.json` | Export temporal del plugin (no commitear) |
| `scripts/tokens/app.mjs` | Transforma tokens.json → theme.css |
| `scripts/tokens/fromFigma.mjs` | Módulo para llamar la REST API de Figma (requiere plan Org/Enterprise) |
| `scripts/tokens/figma-plugin-token-json/code.js` | Plugin de Figma para exportar variables (versión ligera, sin estilos) |
| `scripts/tokens/figma-plugin-token-json/manifest.json` | Manifest del plugin |
| `src/theme.css` | CSS generado automáticamente — NO editar manualmente |
| `src/index.css` | Importa theme.css y define variables globales de layout |
| `.env` | `FIGMA_FILE_KEY=...` (necesario para script:tokens) |
